﻿namespace tastaturavirtualawithbuttonctrl
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.vkkb176 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb175 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb174 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb173 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb172 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb171 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb170 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb169 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb168 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb167 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb166 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb165 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb164 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb163 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb162 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb161 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb160 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb159 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb158 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb157 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb156 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb155 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb154 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb153 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb152 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb151 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb150 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb149 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb148 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb147 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb146 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb145 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb144 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb143 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb142 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb141 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb140 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb139 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb138 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb137 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb136 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb135 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb134 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb133 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb132 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb131 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb130 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb129 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb128 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb127 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb126 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb125 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb124 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb123 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb122 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb121 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb120 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb119 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb118 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb117 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb116 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb115 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb114 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb113 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb112 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb111 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb110 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb109 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb108 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb107 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb106 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb105 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb104 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb103 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb102 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb101 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb100 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb99 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb98 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb97 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb96 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb95 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb94 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb93 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb92 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb91 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb90 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb89 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb88 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb87 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb86 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb85 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb84 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb83 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb82 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb81 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb80 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb79 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb78 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb77 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb76 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb75 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb74 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb73 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb72 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb71 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb70 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb69 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb68 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb67 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb66 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb65 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb64 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb63 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb62 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb61 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb60 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb59 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb58 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb57 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb56 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb55 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb54 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb53 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb52 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb51 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb50 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb49 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb48 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb47 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb46 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb45 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb44 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb43 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb42 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb41 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb40 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb39 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb38 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb37 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb36 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb35 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb34 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb33 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb32 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb31 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb30 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb29 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb28 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb27 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb26 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb25 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb24 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb23 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb22 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb21 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb20 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb19 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb18 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb17 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb16 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb15 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb14 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb13 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb12 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb11 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb10 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb9 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb8 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb7 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb6 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb5 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb4 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb3 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb2 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.vkkb1 = new tastaturavirtualawithbuttonctrl.vkkb();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(43, 12);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(518, 180);
            this.textBox1.TabIndex = 0;
            // 
            // vkkb176
            // 
            this.vkkb176.Location = new System.Drawing.Point(530, 220);
            this.vkkb176.Name = "vkkb176";
            this.vkkb176.Size = new System.Drawing.Size(36, 27);
            this.vkkb176.TabIndex = 176;
            // 
            // vkkb175
            // 
            this.vkkb175.Location = new System.Drawing.Point(498, 220);
            this.vkkb175.Name = "vkkb175";
            this.vkkb175.Size = new System.Drawing.Size(36, 27);
            this.vkkb175.TabIndex = 175;
            // 
            // vkkb174
            // 
            this.vkkb174.Location = new System.Drawing.Point(467, 220);
            this.vkkb174.Name = "vkkb174";
            this.vkkb174.Size = new System.Drawing.Size(36, 27);
            this.vkkb174.TabIndex = 174;
            // 
            // vkkb173
            // 
            this.vkkb173.Location = new System.Drawing.Point(435, 220);
            this.vkkb173.Name = "vkkb173";
            this.vkkb173.Size = new System.Drawing.Size(36, 27);
            this.vkkb173.TabIndex = 173;
            // 
            // vkkb172
            // 
            this.vkkb172.Location = new System.Drawing.Point(402, 220);
            this.vkkb172.Name = "vkkb172";
            this.vkkb172.Size = new System.Drawing.Size(36, 27);
            this.vkkb172.TabIndex = 172;
            // 
            // vkkb171
            // 
            this.vkkb171.Location = new System.Drawing.Point(369, 220);
            this.vkkb171.Name = "vkkb171";
            this.vkkb171.Size = new System.Drawing.Size(36, 27);
            this.vkkb171.TabIndex = 171;
            // 
            // vkkb170
            // 
            this.vkkb170.Location = new System.Drawing.Point(336, 220);
            this.vkkb170.Name = "vkkb170";
            this.vkkb170.Size = new System.Drawing.Size(36, 27);
            this.vkkb170.TabIndex = 170;
            // 
            // vkkb169
            // 
            this.vkkb169.Location = new System.Drawing.Point(303, 220);
            this.vkkb169.Name = "vkkb169";
            this.vkkb169.Size = new System.Drawing.Size(36, 27);
            this.vkkb169.TabIndex = 169;
            // 
            // vkkb168
            // 
            this.vkkb168.Location = new System.Drawing.Point(270, 220);
            this.vkkb168.Name = "vkkb168";
            this.vkkb168.Size = new System.Drawing.Size(36, 27);
            this.vkkb168.TabIndex = 168;
            // 
            // vkkb167
            // 
            this.vkkb167.Location = new System.Drawing.Point(238, 220);
            this.vkkb167.Name = "vkkb167";
            this.vkkb167.Size = new System.Drawing.Size(36, 27);
            this.vkkb167.TabIndex = 167;
            // 
            // vkkb166
            // 
            this.vkkb166.Location = new System.Drawing.Point(205, 220);
            this.vkkb166.Name = "vkkb166";
            this.vkkb166.Size = new System.Drawing.Size(36, 27);
            this.vkkb166.TabIndex = 166;
            // 
            // vkkb165
            // 
            this.vkkb165.Location = new System.Drawing.Point(173, 220);
            this.vkkb165.Name = "vkkb165";
            this.vkkb165.Size = new System.Drawing.Size(36, 27);
            this.vkkb165.TabIndex = 165;
            // 
            // vkkb164
            // 
            this.vkkb164.Location = new System.Drawing.Point(142, 220);
            this.vkkb164.Name = "vkkb164";
            this.vkkb164.Size = new System.Drawing.Size(36, 27);
            this.vkkb164.TabIndex = 164;
            // 
            // vkkb163
            // 
            this.vkkb163.Location = new System.Drawing.Point(109, 220);
            this.vkkb163.Name = "vkkb163";
            this.vkkb163.Size = new System.Drawing.Size(36, 27);
            this.vkkb163.TabIndex = 163;
            // 
            // vkkb162
            // 
            this.vkkb162.Location = new System.Drawing.Point(76, 220);
            this.vkkb162.Name = "vkkb162";
            this.vkkb162.Size = new System.Drawing.Size(36, 27);
            this.vkkb162.TabIndex = 162;
            // 
            // vkkb161
            // 
            this.vkkb161.Location = new System.Drawing.Point(43, 220);
            this.vkkb161.Name = "vkkb161";
            this.vkkb161.Size = new System.Drawing.Size(36, 27);
            this.vkkb161.TabIndex = 161;
            // 
            // vkkb160
            // 
            this.vkkb160.Location = new System.Drawing.Point(531, 198);
            this.vkkb160.Name = "vkkb160";
            this.vkkb160.Size = new System.Drawing.Size(36, 27);
            this.vkkb160.TabIndex = 160;
            // 
            // vkkb159
            // 
            this.vkkb159.Location = new System.Drawing.Point(498, 198);
            this.vkkb159.Name = "vkkb159";
            this.vkkb159.Size = new System.Drawing.Size(36, 27);
            this.vkkb159.TabIndex = 159;
            // 
            // vkkb158
            // 
            this.vkkb158.Location = new System.Drawing.Point(467, 198);
            this.vkkb158.Name = "vkkb158";
            this.vkkb158.Size = new System.Drawing.Size(36, 27);
            this.vkkb158.TabIndex = 158;
            // 
            // vkkb157
            // 
            this.vkkb157.Location = new System.Drawing.Point(435, 198);
            this.vkkb157.Name = "vkkb157";
            this.vkkb157.Size = new System.Drawing.Size(36, 27);
            this.vkkb157.TabIndex = 157;
            // 
            // vkkb156
            // 
            this.vkkb156.Location = new System.Drawing.Point(402, 198);
            this.vkkb156.Name = "vkkb156";
            this.vkkb156.Size = new System.Drawing.Size(36, 27);
            this.vkkb156.TabIndex = 156;
            // 
            // vkkb155
            // 
            this.vkkb155.Location = new System.Drawing.Point(369, 198);
            this.vkkb155.Name = "vkkb155";
            this.vkkb155.Size = new System.Drawing.Size(36, 27);
            this.vkkb155.TabIndex = 155;
            // 
            // vkkb154
            // 
            this.vkkb154.Location = new System.Drawing.Point(336, 198);
            this.vkkb154.Name = "vkkb154";
            this.vkkb154.Size = new System.Drawing.Size(36, 27);
            this.vkkb154.TabIndex = 154;
            // 
            // vkkb153
            // 
            this.vkkb153.Location = new System.Drawing.Point(303, 198);
            this.vkkb153.Name = "vkkb153";
            this.vkkb153.Size = new System.Drawing.Size(36, 27);
            this.vkkb153.TabIndex = 153;
            // 
            // vkkb152
            // 
            this.vkkb152.Location = new System.Drawing.Point(270, 198);
            this.vkkb152.Name = "vkkb152";
            this.vkkb152.Size = new System.Drawing.Size(36, 27);
            this.vkkb152.TabIndex = 152;
            // 
            // vkkb151
            // 
            this.vkkb151.Location = new System.Drawing.Point(238, 198);
            this.vkkb151.Name = "vkkb151";
            this.vkkb151.Size = new System.Drawing.Size(36, 27);
            this.vkkb151.TabIndex = 151;
            // 
            // vkkb150
            // 
            this.vkkb150.Location = new System.Drawing.Point(205, 198);
            this.vkkb150.Name = "vkkb150";
            this.vkkb150.Size = new System.Drawing.Size(36, 27);
            this.vkkb150.TabIndex = 150;
            // 
            // vkkb149
            // 
            this.vkkb149.Location = new System.Drawing.Point(173, 198);
            this.vkkb149.Name = "vkkb149";
            this.vkkb149.Size = new System.Drawing.Size(36, 27);
            this.vkkb149.TabIndex = 149;
            // 
            // vkkb148
            // 
            this.vkkb148.Location = new System.Drawing.Point(142, 198);
            this.vkkb148.Name = "vkkb148";
            this.vkkb148.Size = new System.Drawing.Size(36, 27);
            this.vkkb148.TabIndex = 148;
            // 
            // vkkb147
            // 
            this.vkkb147.Location = new System.Drawing.Point(109, 198);
            this.vkkb147.Name = "vkkb147";
            this.vkkb147.Size = new System.Drawing.Size(36, 27);
            this.vkkb147.TabIndex = 147;
            // 
            // vkkb146
            // 
            this.vkkb146.Location = new System.Drawing.Point(76, 198);
            this.vkkb146.Name = "vkkb146";
            this.vkkb146.Size = new System.Drawing.Size(36, 27);
            this.vkkb146.TabIndex = 146;
            // 
            // vkkb145
            // 
            this.vkkb145.Location = new System.Drawing.Point(43, 198);
            this.vkkb145.Name = "vkkb145";
            this.vkkb145.Size = new System.Drawing.Size(36, 27);
            this.vkkb145.TabIndex = 145;
            // 
            // vkkb144
            // 
            this.vkkb144.Location = new System.Drawing.Point(531, 447);
            this.vkkb144.Name = "vkkb144";
            this.vkkb144.Size = new System.Drawing.Size(36, 27);
            this.vkkb144.TabIndex = 144;
            // 
            // vkkb143
            // 
            this.vkkb143.Location = new System.Drawing.Point(498, 447);
            this.vkkb143.Name = "vkkb143";
            this.vkkb143.Size = new System.Drawing.Size(36, 27);
            this.vkkb143.TabIndex = 143;
            // 
            // vkkb142
            // 
            this.vkkb142.Location = new System.Drawing.Point(467, 447);
            this.vkkb142.Name = "vkkb142";
            this.vkkb142.Size = new System.Drawing.Size(36, 27);
            this.vkkb142.TabIndex = 142;
            // 
            // vkkb141
            // 
            this.vkkb141.Location = new System.Drawing.Point(435, 447);
            this.vkkb141.Name = "vkkb141";
            this.vkkb141.Size = new System.Drawing.Size(36, 27);
            this.vkkb141.TabIndex = 141;
            // 
            // vkkb140
            // 
            this.vkkb140.Location = new System.Drawing.Point(402, 447);
            this.vkkb140.Name = "vkkb140";
            this.vkkb140.Size = new System.Drawing.Size(36, 27);
            this.vkkb140.TabIndex = 140;
            // 
            // vkkb139
            // 
            this.vkkb139.Location = new System.Drawing.Point(369, 447);
            this.vkkb139.Name = "vkkb139";
            this.vkkb139.Size = new System.Drawing.Size(36, 27);
            this.vkkb139.TabIndex = 139;
            // 
            // vkkb138
            // 
            this.vkkb138.Location = new System.Drawing.Point(336, 447);
            this.vkkb138.Name = "vkkb138";
            this.vkkb138.Size = new System.Drawing.Size(36, 27);
            this.vkkb138.TabIndex = 138;
            // 
            // vkkb137
            // 
            this.vkkb137.Location = new System.Drawing.Point(303, 447);
            this.vkkb137.Name = "vkkb137";
            this.vkkb137.Size = new System.Drawing.Size(36, 27);
            this.vkkb137.TabIndex = 137;
            // 
            // vkkb136
            // 
            this.vkkb136.Location = new System.Drawing.Point(270, 447);
            this.vkkb136.Name = "vkkb136";
            this.vkkb136.Size = new System.Drawing.Size(36, 27);
            this.vkkb136.TabIndex = 136;
            // 
            // vkkb135
            // 
            this.vkkb135.Location = new System.Drawing.Point(237, 447);
            this.vkkb135.Name = "vkkb135";
            this.vkkb135.Size = new System.Drawing.Size(36, 27);
            this.vkkb135.TabIndex = 135;
            // 
            // vkkb134
            // 
            this.vkkb134.Location = new System.Drawing.Point(205, 447);
            this.vkkb134.Name = "vkkb134";
            this.vkkb134.Size = new System.Drawing.Size(36, 27);
            this.vkkb134.TabIndex = 134;
            // 
            // vkkb133
            // 
            this.vkkb133.Location = new System.Drawing.Point(173, 447);
            this.vkkb133.Name = "vkkb133";
            this.vkkb133.Size = new System.Drawing.Size(36, 27);
            this.vkkb133.TabIndex = 133;
            // 
            // vkkb132
            // 
            this.vkkb132.Location = new System.Drawing.Point(142, 447);
            this.vkkb132.Name = "vkkb132";
            this.vkkb132.Size = new System.Drawing.Size(36, 27);
            this.vkkb132.TabIndex = 132;
            // 
            // vkkb131
            // 
            this.vkkb131.Location = new System.Drawing.Point(109, 447);
            this.vkkb131.Name = "vkkb131";
            this.vkkb131.Size = new System.Drawing.Size(36, 27);
            this.vkkb131.TabIndex = 131;
            // 
            // vkkb130
            // 
            this.vkkb130.Location = new System.Drawing.Point(76, 447);
            this.vkkb130.Name = "vkkb130";
            this.vkkb130.Size = new System.Drawing.Size(36, 27);
            this.vkkb130.TabIndex = 130;
            // 
            // vkkb129
            // 
            this.vkkb129.Location = new System.Drawing.Point(43, 447);
            this.vkkb129.Name = "vkkb129";
            this.vkkb129.Size = new System.Drawing.Size(36, 27);
            this.vkkb129.TabIndex = 129;
            // 
            // vkkb128
            // 
            this.vkkb128.Location = new System.Drawing.Point(530, 423);
            this.vkkb128.Name = "vkkb128";
            this.vkkb128.Size = new System.Drawing.Size(36, 27);
            this.vkkb128.TabIndex = 128;
            // 
            // vkkb127
            // 
            this.vkkb127.Location = new System.Drawing.Point(498, 423);
            this.vkkb127.Name = "vkkb127";
            this.vkkb127.Size = new System.Drawing.Size(36, 27);
            this.vkkb127.TabIndex = 127;
            // 
            // vkkb126
            // 
            this.vkkb126.Location = new System.Drawing.Point(467, 423);
            this.vkkb126.Name = "vkkb126";
            this.vkkb126.Size = new System.Drawing.Size(36, 27);
            this.vkkb126.TabIndex = 126;
            // 
            // vkkb125
            // 
            this.vkkb125.Location = new System.Drawing.Point(435, 423);
            this.vkkb125.Name = "vkkb125";
            this.vkkb125.Size = new System.Drawing.Size(36, 27);
            this.vkkb125.TabIndex = 125;
            // 
            // vkkb124
            // 
            this.vkkb124.Location = new System.Drawing.Point(402, 423);
            this.vkkb124.Name = "vkkb124";
            this.vkkb124.Size = new System.Drawing.Size(36, 27);
            this.vkkb124.TabIndex = 124;
            // 
            // vkkb123
            // 
            this.vkkb123.Location = new System.Drawing.Point(369, 423);
            this.vkkb123.Name = "vkkb123";
            this.vkkb123.Size = new System.Drawing.Size(36, 27);
            this.vkkb123.TabIndex = 123;
            // 
            // vkkb122
            // 
            this.vkkb122.Location = new System.Drawing.Point(336, 423);
            this.vkkb122.Name = "vkkb122";
            this.vkkb122.Size = new System.Drawing.Size(36, 27);
            this.vkkb122.TabIndex = 122;
            // 
            // vkkb121
            // 
            this.vkkb121.Location = new System.Drawing.Point(303, 423);
            this.vkkb121.Name = "vkkb121";
            this.vkkb121.Size = new System.Drawing.Size(36, 27);
            this.vkkb121.TabIndex = 121;
            // 
            // vkkb120
            // 
            this.vkkb120.Location = new System.Drawing.Point(270, 423);
            this.vkkb120.Name = "vkkb120";
            this.vkkb120.Size = new System.Drawing.Size(36, 27);
            this.vkkb120.TabIndex = 120;
            // 
            // vkkb119
            // 
            this.vkkb119.Location = new System.Drawing.Point(237, 423);
            this.vkkb119.Name = "vkkb119";
            this.vkkb119.Size = new System.Drawing.Size(36, 27);
            this.vkkb119.TabIndex = 119;
            // 
            // vkkb118
            // 
            this.vkkb118.Location = new System.Drawing.Point(205, 423);
            this.vkkb118.Name = "vkkb118";
            this.vkkb118.Size = new System.Drawing.Size(36, 27);
            this.vkkb118.TabIndex = 118;
            // 
            // vkkb117
            // 
            this.vkkb117.Location = new System.Drawing.Point(173, 423);
            this.vkkb117.Name = "vkkb117";
            this.vkkb117.Size = new System.Drawing.Size(36, 27);
            this.vkkb117.TabIndex = 117;
            // 
            // vkkb116
            // 
            this.vkkb116.Location = new System.Drawing.Point(142, 423);
            this.vkkb116.Name = "vkkb116";
            this.vkkb116.Size = new System.Drawing.Size(36, 27);
            this.vkkb116.TabIndex = 116;
            // 
            // vkkb115
            // 
            this.vkkb115.Location = new System.Drawing.Point(109, 423);
            this.vkkb115.Name = "vkkb115";
            this.vkkb115.Size = new System.Drawing.Size(36, 27);
            this.vkkb115.TabIndex = 115;
            // 
            // vkkb114
            // 
            this.vkkb114.Location = new System.Drawing.Point(76, 423);
            this.vkkb114.Name = "vkkb114";
            this.vkkb114.Size = new System.Drawing.Size(36, 27);
            this.vkkb114.TabIndex = 114;
            // 
            // vkkb113
            // 
            this.vkkb113.Location = new System.Drawing.Point(43, 423);
            this.vkkb113.Name = "vkkb113";
            this.vkkb113.Size = new System.Drawing.Size(36, 27);
            this.vkkb113.TabIndex = 113;
            // 
            // vkkb112
            // 
            this.vkkb112.Location = new System.Drawing.Point(530, 399);
            this.vkkb112.Name = "vkkb112";
            this.vkkb112.Size = new System.Drawing.Size(36, 27);
            this.vkkb112.TabIndex = 112;
            // 
            // vkkb111
            // 
            this.vkkb111.Location = new System.Drawing.Point(498, 399);
            this.vkkb111.Name = "vkkb111";
            this.vkkb111.Size = new System.Drawing.Size(36, 27);
            this.vkkb111.TabIndex = 111;
            // 
            // vkkb110
            // 
            this.vkkb110.Location = new System.Drawing.Point(467, 399);
            this.vkkb110.Name = "vkkb110";
            this.vkkb110.Size = new System.Drawing.Size(36, 27);
            this.vkkb110.TabIndex = 110;
            // 
            // vkkb109
            // 
            this.vkkb109.Location = new System.Drawing.Point(435, 399);
            this.vkkb109.Name = "vkkb109";
            this.vkkb109.Size = new System.Drawing.Size(36, 27);
            this.vkkb109.TabIndex = 109;
            // 
            // vkkb108
            // 
            this.vkkb108.Location = new System.Drawing.Point(402, 399);
            this.vkkb108.Name = "vkkb108";
            this.vkkb108.Size = new System.Drawing.Size(36, 27);
            this.vkkb108.TabIndex = 108;
            // 
            // vkkb107
            // 
            this.vkkb107.Location = new System.Drawing.Point(369, 399);
            this.vkkb107.Name = "vkkb107";
            this.vkkb107.Size = new System.Drawing.Size(36, 27);
            this.vkkb107.TabIndex = 107;
            // 
            // vkkb106
            // 
            this.vkkb106.Location = new System.Drawing.Point(336, 399);
            this.vkkb106.Name = "vkkb106";
            this.vkkb106.Size = new System.Drawing.Size(36, 27);
            this.vkkb106.TabIndex = 106;
            // 
            // vkkb105
            // 
            this.vkkb105.Location = new System.Drawing.Point(303, 399);
            this.vkkb105.Name = "vkkb105";
            this.vkkb105.Size = new System.Drawing.Size(36, 27);
            this.vkkb105.TabIndex = 105;
            // 
            // vkkb104
            // 
            this.vkkb104.Location = new System.Drawing.Point(270, 399);
            this.vkkb104.Name = "vkkb104";
            this.vkkb104.Size = new System.Drawing.Size(36, 27);
            this.vkkb104.TabIndex = 104;
            // 
            // vkkb103
            // 
            this.vkkb103.Location = new System.Drawing.Point(237, 399);
            this.vkkb103.Name = "vkkb103";
            this.vkkb103.Size = new System.Drawing.Size(36, 27);
            this.vkkb103.TabIndex = 103;
            // 
            // vkkb102
            // 
            this.vkkb102.Location = new System.Drawing.Point(205, 399);
            this.vkkb102.Name = "vkkb102";
            this.vkkb102.Size = new System.Drawing.Size(36, 27);
            this.vkkb102.TabIndex = 102;
            // 
            // vkkb101
            // 
            this.vkkb101.Location = new System.Drawing.Point(173, 399);
            this.vkkb101.Name = "vkkb101";
            this.vkkb101.Size = new System.Drawing.Size(36, 27);
            this.vkkb101.TabIndex = 101;
            // 
            // vkkb100
            // 
            this.vkkb100.Location = new System.Drawing.Point(142, 399);
            this.vkkb100.Name = "vkkb100";
            this.vkkb100.Size = new System.Drawing.Size(36, 27);
            this.vkkb100.TabIndex = 100;
            // 
            // vkkb99
            // 
            this.vkkb99.Location = new System.Drawing.Point(109, 399);
            this.vkkb99.Name = "vkkb99";
            this.vkkb99.Size = new System.Drawing.Size(36, 27);
            this.vkkb99.TabIndex = 99;
            // 
            // vkkb98
            // 
            this.vkkb98.Location = new System.Drawing.Point(76, 399);
            this.vkkb98.Name = "vkkb98";
            this.vkkb98.Size = new System.Drawing.Size(36, 27);
            this.vkkb98.TabIndex = 98;
            // 
            // vkkb97
            // 
            this.vkkb97.Location = new System.Drawing.Point(43, 399);
            this.vkkb97.Name = "vkkb97";
            this.vkkb97.Size = new System.Drawing.Size(36, 27);
            this.vkkb97.TabIndex = 97;
            // 
            // vkkb96
            // 
            this.vkkb96.Location = new System.Drawing.Point(530, 376);
            this.vkkb96.Name = "vkkb96";
            this.vkkb96.Size = new System.Drawing.Size(36, 27);
            this.vkkb96.TabIndex = 96;
            // 
            // vkkb95
            // 
            this.vkkb95.Location = new System.Drawing.Point(498, 376);
            this.vkkb95.Name = "vkkb95";
            this.vkkb95.Size = new System.Drawing.Size(36, 27);
            this.vkkb95.TabIndex = 95;
            // 
            // vkkb94
            // 
            this.vkkb94.Location = new System.Drawing.Point(467, 376);
            this.vkkb94.Name = "vkkb94";
            this.vkkb94.Size = new System.Drawing.Size(36, 27);
            this.vkkb94.TabIndex = 94;
            // 
            // vkkb93
            // 
            this.vkkb93.Location = new System.Drawing.Point(435, 376);
            this.vkkb93.Name = "vkkb93";
            this.vkkb93.Size = new System.Drawing.Size(36, 27);
            this.vkkb93.TabIndex = 93;
            // 
            // vkkb92
            // 
            this.vkkb92.Location = new System.Drawing.Point(402, 376);
            this.vkkb92.Name = "vkkb92";
            this.vkkb92.Size = new System.Drawing.Size(36, 27);
            this.vkkb92.TabIndex = 92;
            // 
            // vkkb91
            // 
            this.vkkb91.Location = new System.Drawing.Point(369, 376);
            this.vkkb91.Name = "vkkb91";
            this.vkkb91.Size = new System.Drawing.Size(36, 27);
            this.vkkb91.TabIndex = 91;
            // 
            // vkkb90
            // 
            this.vkkb90.Location = new System.Drawing.Point(336, 376);
            this.vkkb90.Name = "vkkb90";
            this.vkkb90.Size = new System.Drawing.Size(36, 27);
            this.vkkb90.TabIndex = 90;
            // 
            // vkkb89
            // 
            this.vkkb89.Location = new System.Drawing.Point(303, 376);
            this.vkkb89.Name = "vkkb89";
            this.vkkb89.Size = new System.Drawing.Size(36, 27);
            this.vkkb89.TabIndex = 89;
            // 
            // vkkb88
            // 
            this.vkkb88.Location = new System.Drawing.Point(270, 376);
            this.vkkb88.Name = "vkkb88";
            this.vkkb88.Size = new System.Drawing.Size(36, 27);
            this.vkkb88.TabIndex = 88;
            // 
            // vkkb87
            // 
            this.vkkb87.Location = new System.Drawing.Point(237, 376);
            this.vkkb87.Name = "vkkb87";
            this.vkkb87.Size = new System.Drawing.Size(36, 27);
            this.vkkb87.TabIndex = 87;
            // 
            // vkkb86
            // 
            this.vkkb86.Location = new System.Drawing.Point(205, 376);
            this.vkkb86.Name = "vkkb86";
            this.vkkb86.Size = new System.Drawing.Size(36, 27);
            this.vkkb86.TabIndex = 86;
            // 
            // vkkb85
            // 
            this.vkkb85.Location = new System.Drawing.Point(173, 376);
            this.vkkb85.Name = "vkkb85";
            this.vkkb85.Size = new System.Drawing.Size(36, 27);
            this.vkkb85.TabIndex = 85;
            // 
            // vkkb84
            // 
            this.vkkb84.Location = new System.Drawing.Point(142, 376);
            this.vkkb84.Name = "vkkb84";
            this.vkkb84.Size = new System.Drawing.Size(36, 27);
            this.vkkb84.TabIndex = 84;
            // 
            // vkkb83
            // 
            this.vkkb83.Location = new System.Drawing.Point(109, 376);
            this.vkkb83.Name = "vkkb83";
            this.vkkb83.Size = new System.Drawing.Size(36, 27);
            this.vkkb83.TabIndex = 83;
            // 
            // vkkb82
            // 
            this.vkkb82.Location = new System.Drawing.Point(76, 376);
            this.vkkb82.Name = "vkkb82";
            this.vkkb82.Size = new System.Drawing.Size(36, 27);
            this.vkkb82.TabIndex = 82;
            // 
            // vkkb81
            // 
            this.vkkb81.Location = new System.Drawing.Point(43, 376);
            this.vkkb81.Name = "vkkb81";
            this.vkkb81.Size = new System.Drawing.Size(36, 27);
            this.vkkb81.TabIndex = 81;
            // 
            // vkkb80
            // 
            this.vkkb80.Location = new System.Drawing.Point(530, 350);
            this.vkkb80.Name = "vkkb80";
            this.vkkb80.Size = new System.Drawing.Size(36, 27);
            this.vkkb80.TabIndex = 80;
            // 
            // vkkb79
            // 
            this.vkkb79.Location = new System.Drawing.Point(498, 350);
            this.vkkb79.Name = "vkkb79";
            this.vkkb79.Size = new System.Drawing.Size(36, 27);
            this.vkkb79.TabIndex = 79;
            // 
            // vkkb78
            // 
            this.vkkb78.Location = new System.Drawing.Point(467, 350);
            this.vkkb78.Name = "vkkb78";
            this.vkkb78.Size = new System.Drawing.Size(36, 27);
            this.vkkb78.TabIndex = 78;
            // 
            // vkkb77
            // 
            this.vkkb77.Location = new System.Drawing.Point(435, 350);
            this.vkkb77.Name = "vkkb77";
            this.vkkb77.Size = new System.Drawing.Size(36, 27);
            this.vkkb77.TabIndex = 77;
            // 
            // vkkb76
            // 
            this.vkkb76.Location = new System.Drawing.Point(402, 350);
            this.vkkb76.Name = "vkkb76";
            this.vkkb76.Size = new System.Drawing.Size(36, 27);
            this.vkkb76.TabIndex = 76;
            // 
            // vkkb75
            // 
            this.vkkb75.Location = new System.Drawing.Point(369, 350);
            this.vkkb75.Name = "vkkb75";
            this.vkkb75.Size = new System.Drawing.Size(36, 27);
            this.vkkb75.TabIndex = 75;
            // 
            // vkkb74
            // 
            this.vkkb74.Location = new System.Drawing.Point(336, 350);
            this.vkkb74.Name = "vkkb74";
            this.vkkb74.Size = new System.Drawing.Size(36, 27);
            this.vkkb74.TabIndex = 74;
            // 
            // vkkb73
            // 
            this.vkkb73.Location = new System.Drawing.Point(303, 350);
            this.vkkb73.Name = "vkkb73";
            this.vkkb73.Size = new System.Drawing.Size(36, 27);
            this.vkkb73.TabIndex = 73;
            // 
            // vkkb72
            // 
            this.vkkb72.Location = new System.Drawing.Point(270, 350);
            this.vkkb72.Name = "vkkb72";
            this.vkkb72.Size = new System.Drawing.Size(36, 27);
            this.vkkb72.TabIndex = 72;
            // 
            // vkkb71
            // 
            this.vkkb71.Location = new System.Drawing.Point(237, 350);
            this.vkkb71.Name = "vkkb71";
            this.vkkb71.Size = new System.Drawing.Size(36, 27);
            this.vkkb71.TabIndex = 71;
            // 
            // vkkb70
            // 
            this.vkkb70.Location = new System.Drawing.Point(205, 350);
            this.vkkb70.Name = "vkkb70";
            this.vkkb70.Size = new System.Drawing.Size(36, 27);
            this.vkkb70.TabIndex = 70;
            // 
            // vkkb69
            // 
            this.vkkb69.Location = new System.Drawing.Point(173, 350);
            this.vkkb69.Name = "vkkb69";
            this.vkkb69.Size = new System.Drawing.Size(36, 27);
            this.vkkb69.TabIndex = 69;
            // 
            // vkkb68
            // 
            this.vkkb68.Location = new System.Drawing.Point(142, 350);
            this.vkkb68.Name = "vkkb68";
            this.vkkb68.Size = new System.Drawing.Size(36, 27);
            this.vkkb68.TabIndex = 68;
            // 
            // vkkb67
            // 
            this.vkkb67.Location = new System.Drawing.Point(109, 350);
            this.vkkb67.Name = "vkkb67";
            this.vkkb67.Size = new System.Drawing.Size(36, 27);
            this.vkkb67.TabIndex = 67;
            // 
            // vkkb66
            // 
            this.vkkb66.Location = new System.Drawing.Point(76, 350);
            this.vkkb66.Name = "vkkb66";
            this.vkkb66.Size = new System.Drawing.Size(36, 27);
            this.vkkb66.TabIndex = 66;
            // 
            // vkkb65
            // 
            this.vkkb65.Location = new System.Drawing.Point(43, 350);
            this.vkkb65.Name = "vkkb65";
            this.vkkb65.Size = new System.Drawing.Size(36, 27);
            this.vkkb65.TabIndex = 65;
            // 
            // vkkb64
            // 
            this.vkkb64.Location = new System.Drawing.Point(530, 324);
            this.vkkb64.Name = "vkkb64";
            this.vkkb64.Size = new System.Drawing.Size(36, 27);
            this.vkkb64.TabIndex = 64;
            // 
            // vkkb63
            // 
            this.vkkb63.Location = new System.Drawing.Point(498, 324);
            this.vkkb63.Name = "vkkb63";
            this.vkkb63.Size = new System.Drawing.Size(36, 27);
            this.vkkb63.TabIndex = 63;
            // 
            // vkkb62
            // 
            this.vkkb62.Location = new System.Drawing.Point(467, 324);
            this.vkkb62.Name = "vkkb62";
            this.vkkb62.Size = new System.Drawing.Size(36, 27);
            this.vkkb62.TabIndex = 62;
            // 
            // vkkb61
            // 
            this.vkkb61.Location = new System.Drawing.Point(435, 324);
            this.vkkb61.Name = "vkkb61";
            this.vkkb61.Size = new System.Drawing.Size(36, 27);
            this.vkkb61.TabIndex = 61;
            // 
            // vkkb60
            // 
            this.vkkb60.Location = new System.Drawing.Point(402, 324);
            this.vkkb60.Name = "vkkb60";
            this.vkkb60.Size = new System.Drawing.Size(36, 27);
            this.vkkb60.TabIndex = 60;
            // 
            // vkkb59
            // 
            this.vkkb59.Location = new System.Drawing.Point(369, 324);
            this.vkkb59.Name = "vkkb59";
            this.vkkb59.Size = new System.Drawing.Size(36, 27);
            this.vkkb59.TabIndex = 59;
            // 
            // vkkb58
            // 
            this.vkkb58.Location = new System.Drawing.Point(336, 324);
            this.vkkb58.Name = "vkkb58";
            this.vkkb58.Size = new System.Drawing.Size(36, 27);
            this.vkkb58.TabIndex = 58;
            // 
            // vkkb57
            // 
            this.vkkb57.Location = new System.Drawing.Point(303, 324);
            this.vkkb57.Name = "vkkb57";
            this.vkkb57.Size = new System.Drawing.Size(36, 27);
            this.vkkb57.TabIndex = 57;
            // 
            // vkkb56
            // 
            this.vkkb56.Location = new System.Drawing.Point(270, 324);
            this.vkkb56.Name = "vkkb56";
            this.vkkb56.Size = new System.Drawing.Size(36, 27);
            this.vkkb56.TabIndex = 56;
            // 
            // vkkb55
            // 
            this.vkkb55.Location = new System.Drawing.Point(237, 324);
            this.vkkb55.Name = "vkkb55";
            this.vkkb55.Size = new System.Drawing.Size(36, 27);
            this.vkkb55.TabIndex = 55;
            // 
            // vkkb54
            // 
            this.vkkb54.Location = new System.Drawing.Point(205, 324);
            this.vkkb54.Name = "vkkb54";
            this.vkkb54.Size = new System.Drawing.Size(36, 27);
            this.vkkb54.TabIndex = 54;
            // 
            // vkkb53
            // 
            this.vkkb53.Location = new System.Drawing.Point(173, 324);
            this.vkkb53.Name = "vkkb53";
            this.vkkb53.Size = new System.Drawing.Size(36, 27);
            this.vkkb53.TabIndex = 53;
            // 
            // vkkb52
            // 
            this.vkkb52.Location = new System.Drawing.Point(142, 324);
            this.vkkb52.Name = "vkkb52";
            this.vkkb52.Size = new System.Drawing.Size(36, 27);
            this.vkkb52.TabIndex = 52;
            // 
            // vkkb51
            // 
            this.vkkb51.Location = new System.Drawing.Point(109, 324);
            this.vkkb51.Name = "vkkb51";
            this.vkkb51.Size = new System.Drawing.Size(36, 27);
            this.vkkb51.TabIndex = 51;
            // 
            // vkkb50
            // 
            this.vkkb50.Location = new System.Drawing.Point(76, 324);
            this.vkkb50.Name = "vkkb50";
            this.vkkb50.Size = new System.Drawing.Size(36, 27);
            this.vkkb50.TabIndex = 50;
            // 
            // vkkb49
            // 
            this.vkkb49.Location = new System.Drawing.Point(43, 324);
            this.vkkb49.Name = "vkkb49";
            this.vkkb49.Size = new System.Drawing.Size(36, 27);
            this.vkkb49.TabIndex = 49;
            // 
            // vkkb48
            // 
            this.vkkb48.Location = new System.Drawing.Point(530, 301);
            this.vkkb48.Name = "vkkb48";
            this.vkkb48.Size = new System.Drawing.Size(36, 27);
            this.vkkb48.TabIndex = 48;
            // 
            // vkkb47
            // 
            this.vkkb47.Location = new System.Drawing.Point(498, 301);
            this.vkkb47.Name = "vkkb47";
            this.vkkb47.Size = new System.Drawing.Size(36, 27);
            this.vkkb47.TabIndex = 47;
            // 
            // vkkb46
            // 
            this.vkkb46.Location = new System.Drawing.Point(467, 301);
            this.vkkb46.Name = "vkkb46";
            this.vkkb46.Size = new System.Drawing.Size(36, 27);
            this.vkkb46.TabIndex = 46;
            // 
            // vkkb45
            // 
            this.vkkb45.Location = new System.Drawing.Point(435, 301);
            this.vkkb45.Name = "vkkb45";
            this.vkkb45.Size = new System.Drawing.Size(36, 27);
            this.vkkb45.TabIndex = 45;
            // 
            // vkkb44
            // 
            this.vkkb44.Location = new System.Drawing.Point(402, 301);
            this.vkkb44.Name = "vkkb44";
            this.vkkb44.Size = new System.Drawing.Size(36, 27);
            this.vkkb44.TabIndex = 44;
            // 
            // vkkb43
            // 
            this.vkkb43.Location = new System.Drawing.Point(369, 301);
            this.vkkb43.Name = "vkkb43";
            this.vkkb43.Size = new System.Drawing.Size(36, 27);
            this.vkkb43.TabIndex = 43;
            // 
            // vkkb42
            // 
            this.vkkb42.Location = new System.Drawing.Point(336, 301);
            this.vkkb42.Name = "vkkb42";
            this.vkkb42.Size = new System.Drawing.Size(36, 27);
            this.vkkb42.TabIndex = 42;
            // 
            // vkkb41
            // 
            this.vkkb41.Location = new System.Drawing.Point(303, 301);
            this.vkkb41.Name = "vkkb41";
            this.vkkb41.Size = new System.Drawing.Size(36, 27);
            this.vkkb41.TabIndex = 41;
            // 
            // vkkb40
            // 
            this.vkkb40.Location = new System.Drawing.Point(270, 301);
            this.vkkb40.Name = "vkkb40";
            this.vkkb40.Size = new System.Drawing.Size(36, 27);
            this.vkkb40.TabIndex = 40;
            // 
            // vkkb39
            // 
            this.vkkb39.Location = new System.Drawing.Point(238, 301);
            this.vkkb39.Name = "vkkb39";
            this.vkkb39.Size = new System.Drawing.Size(36, 27);
            this.vkkb39.TabIndex = 39;
            // 
            // vkkb38
            // 
            this.vkkb38.Location = new System.Drawing.Point(205, 301);
            this.vkkb38.Name = "vkkb38";
            this.vkkb38.Size = new System.Drawing.Size(36, 27);
            this.vkkb38.TabIndex = 38;
            // 
            // vkkb37
            // 
            this.vkkb37.Location = new System.Drawing.Point(173, 301);
            this.vkkb37.Name = "vkkb37";
            this.vkkb37.Size = new System.Drawing.Size(36, 27);
            this.vkkb37.TabIndex = 37;
            // 
            // vkkb36
            // 
            this.vkkb36.Location = new System.Drawing.Point(142, 301);
            this.vkkb36.Name = "vkkb36";
            this.vkkb36.Size = new System.Drawing.Size(36, 27);
            this.vkkb36.TabIndex = 36;
            // 
            // vkkb35
            // 
            this.vkkb35.Location = new System.Drawing.Point(109, 301);
            this.vkkb35.Name = "vkkb35";
            this.vkkb35.Size = new System.Drawing.Size(36, 27);
            this.vkkb35.TabIndex = 35;
            // 
            // vkkb34
            // 
            this.vkkb34.Location = new System.Drawing.Point(76, 301);
            this.vkkb34.Name = "vkkb34";
            this.vkkb34.Size = new System.Drawing.Size(36, 27);
            this.vkkb34.TabIndex = 34;
            // 
            // vkkb33
            // 
            this.vkkb33.Location = new System.Drawing.Point(43, 301);
            this.vkkb33.Name = "vkkb33";
            this.vkkb33.Size = new System.Drawing.Size(36, 27);
            this.vkkb33.TabIndex = 33;
            // 
            // vkkb32
            // 
            this.vkkb32.Location = new System.Drawing.Point(530, 274);
            this.vkkb32.Name = "vkkb32";
            this.vkkb32.Size = new System.Drawing.Size(36, 27);
            this.vkkb32.TabIndex = 32;
            // 
            // vkkb31
            // 
            this.vkkb31.Location = new System.Drawing.Point(498, 274);
            this.vkkb31.Name = "vkkb31";
            this.vkkb31.Size = new System.Drawing.Size(36, 27);
            this.vkkb31.TabIndex = 31;
            // 
            // vkkb30
            // 
            this.vkkb30.Location = new System.Drawing.Point(467, 274);
            this.vkkb30.Name = "vkkb30";
            this.vkkb30.Size = new System.Drawing.Size(36, 27);
            this.vkkb30.TabIndex = 30;
            // 
            // vkkb29
            // 
            this.vkkb29.Location = new System.Drawing.Point(435, 274);
            this.vkkb29.Name = "vkkb29";
            this.vkkb29.Size = new System.Drawing.Size(36, 27);
            this.vkkb29.TabIndex = 29;
            // 
            // vkkb28
            // 
            this.vkkb28.Location = new System.Drawing.Point(402, 274);
            this.vkkb28.Name = "vkkb28";
            this.vkkb28.Size = new System.Drawing.Size(36, 27);
            this.vkkb28.TabIndex = 28;
            // 
            // vkkb27
            // 
            this.vkkb27.Location = new System.Drawing.Point(369, 274);
            this.vkkb27.Name = "vkkb27";
            this.vkkb27.Size = new System.Drawing.Size(36, 27);
            this.vkkb27.TabIndex = 27;
            // 
            // vkkb26
            // 
            this.vkkb26.Location = new System.Drawing.Point(336, 274);
            this.vkkb26.Name = "vkkb26";
            this.vkkb26.Size = new System.Drawing.Size(36, 27);
            this.vkkb26.TabIndex = 26;
            // 
            // vkkb25
            // 
            this.vkkb25.Location = new System.Drawing.Point(303, 274);
            this.vkkb25.Name = "vkkb25";
            this.vkkb25.Size = new System.Drawing.Size(36, 27);
            this.vkkb25.TabIndex = 25;
            // 
            // vkkb24
            // 
            this.vkkb24.Location = new System.Drawing.Point(270, 274);
            this.vkkb24.Name = "vkkb24";
            this.vkkb24.Size = new System.Drawing.Size(36, 27);
            this.vkkb24.TabIndex = 24;
            // 
            // vkkb23
            // 
            this.vkkb23.Location = new System.Drawing.Point(237, 274);
            this.vkkb23.Name = "vkkb23";
            this.vkkb23.Size = new System.Drawing.Size(36, 27);
            this.vkkb23.TabIndex = 23;
            // 
            // vkkb22
            // 
            this.vkkb22.Location = new System.Drawing.Point(205, 274);
            this.vkkb22.Name = "vkkb22";
            this.vkkb22.Size = new System.Drawing.Size(36, 27);
            this.vkkb22.TabIndex = 22;
            // 
            // vkkb21
            // 
            this.vkkb21.Location = new System.Drawing.Point(173, 274);
            this.vkkb21.Name = "vkkb21";
            this.vkkb21.Size = new System.Drawing.Size(36, 27);
            this.vkkb21.TabIndex = 21;
            // 
            // vkkb20
            // 
            this.vkkb20.Location = new System.Drawing.Point(142, 274);
            this.vkkb20.Name = "vkkb20";
            this.vkkb20.Size = new System.Drawing.Size(36, 27);
            this.vkkb20.TabIndex = 20;
            // 
            // vkkb19
            // 
            this.vkkb19.Location = new System.Drawing.Point(109, 274);
            this.vkkb19.Name = "vkkb19";
            this.vkkb19.Size = new System.Drawing.Size(36, 27);
            this.vkkb19.TabIndex = 19;
            // 
            // vkkb18
            // 
            this.vkkb18.Location = new System.Drawing.Point(76, 274);
            this.vkkb18.Name = "vkkb18";
            this.vkkb18.Size = new System.Drawing.Size(36, 27);
            this.vkkb18.TabIndex = 18;
            // 
            // vkkb17
            // 
            this.vkkb17.Location = new System.Drawing.Point(43, 274);
            this.vkkb17.Name = "vkkb17";
            this.vkkb17.Size = new System.Drawing.Size(36, 27);
            this.vkkb17.TabIndex = 17;
            // 
            // vkkb16
            // 
            this.vkkb16.Location = new System.Drawing.Point(530, 247);
            this.vkkb16.Name = "vkkb16";
            this.vkkb16.Size = new System.Drawing.Size(36, 27);
            this.vkkb16.TabIndex = 16;
            // 
            // vkkb15
            // 
            this.vkkb15.Location = new System.Drawing.Point(498, 246);
            this.vkkb15.Name = "vkkb15";
            this.vkkb15.Size = new System.Drawing.Size(36, 27);
            this.vkkb15.TabIndex = 15;
            // 
            // vkkb14
            // 
            this.vkkb14.Location = new System.Drawing.Point(467, 246);
            this.vkkb14.Name = "vkkb14";
            this.vkkb14.Size = new System.Drawing.Size(36, 27);
            this.vkkb14.TabIndex = 14;
            // 
            // vkkb13
            // 
            this.vkkb13.Location = new System.Drawing.Point(435, 247);
            this.vkkb13.Name = "vkkb13";
            this.vkkb13.Size = new System.Drawing.Size(36, 27);
            this.vkkb13.TabIndex = 13;
            // 
            // vkkb12
            // 
            this.vkkb12.Location = new System.Drawing.Point(402, 247);
            this.vkkb12.Name = "vkkb12";
            this.vkkb12.Size = new System.Drawing.Size(36, 27);
            this.vkkb12.TabIndex = 12;
            // 
            // vkkb11
            // 
            this.vkkb11.Location = new System.Drawing.Point(369, 247);
            this.vkkb11.Name = "vkkb11";
            this.vkkb11.Size = new System.Drawing.Size(36, 27);
            this.vkkb11.TabIndex = 11;
            // 
            // vkkb10
            // 
            this.vkkb10.Location = new System.Drawing.Point(336, 246);
            this.vkkb10.Name = "vkkb10";
            this.vkkb10.Size = new System.Drawing.Size(36, 27);
            this.vkkb10.TabIndex = 10;
            // 
            // vkkb9
            // 
            this.vkkb9.Location = new System.Drawing.Point(303, 246);
            this.vkkb9.Name = "vkkb9";
            this.vkkb9.Size = new System.Drawing.Size(36, 27);
            this.vkkb9.TabIndex = 9;
            // 
            // vkkb8
            // 
            this.vkkb8.Location = new System.Drawing.Point(270, 247);
            this.vkkb8.Name = "vkkb8";
            this.vkkb8.Size = new System.Drawing.Size(36, 27);
            this.vkkb8.TabIndex = 8;
            // 
            // vkkb7
            // 
            this.vkkb7.Location = new System.Drawing.Point(238, 247);
            this.vkkb7.Name = "vkkb7";
            this.vkkb7.Size = new System.Drawing.Size(36, 27);
            this.vkkb7.TabIndex = 7;
            // 
            // vkkb6
            // 
            this.vkkb6.Location = new System.Drawing.Point(205, 247);
            this.vkkb6.Name = "vkkb6";
            this.vkkb6.Size = new System.Drawing.Size(36, 27);
            this.vkkb6.TabIndex = 6;
            // 
            // vkkb5
            // 
            this.vkkb5.Location = new System.Drawing.Point(173, 247);
            this.vkkb5.Name = "vkkb5";
            this.vkkb5.Size = new System.Drawing.Size(36, 27);
            this.vkkb5.TabIndex = 5;
            // 
            // vkkb4
            // 
            this.vkkb4.Location = new System.Drawing.Point(142, 247);
            this.vkkb4.Name = "vkkb4";
            this.vkkb4.Size = new System.Drawing.Size(36, 27);
            this.vkkb4.TabIndex = 4;
            // 
            // vkkb3
            // 
            this.vkkb3.Location = new System.Drawing.Point(109, 247);
            this.vkkb3.Name = "vkkb3";
            this.vkkb3.Size = new System.Drawing.Size(36, 27);
            this.vkkb3.TabIndex = 3;
            // 
            // vkkb2
            // 
            this.vkkb2.Location = new System.Drawing.Point(76, 247);
            this.vkkb2.Name = "vkkb2";
            this.vkkb2.Size = new System.Drawing.Size(36, 27);
            this.vkkb2.TabIndex = 2;
            // 
            // vkkb1
            // 
            this.vkkb1.Location = new System.Drawing.Point(43, 247);
            this.vkkb1.Name = "vkkb1";
            this.vkkb1.Size = new System.Drawing.Size(36, 27);
            this.vkkb1.TabIndex = 1;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(618, 482);
            this.Controls.Add(this.vkkb176);
            this.Controls.Add(this.vkkb175);
            this.Controls.Add(this.vkkb174);
            this.Controls.Add(this.vkkb173);
            this.Controls.Add(this.vkkb172);
            this.Controls.Add(this.vkkb171);
            this.Controls.Add(this.vkkb170);
            this.Controls.Add(this.vkkb169);
            this.Controls.Add(this.vkkb168);
            this.Controls.Add(this.vkkb167);
            this.Controls.Add(this.vkkb166);
            this.Controls.Add(this.vkkb165);
            this.Controls.Add(this.vkkb164);
            this.Controls.Add(this.vkkb163);
            this.Controls.Add(this.vkkb162);
            this.Controls.Add(this.vkkb161);
            this.Controls.Add(this.vkkb160);
            this.Controls.Add(this.vkkb159);
            this.Controls.Add(this.vkkb158);
            this.Controls.Add(this.vkkb157);
            this.Controls.Add(this.vkkb156);
            this.Controls.Add(this.vkkb155);
            this.Controls.Add(this.vkkb154);
            this.Controls.Add(this.vkkb153);
            this.Controls.Add(this.vkkb152);
            this.Controls.Add(this.vkkb151);
            this.Controls.Add(this.vkkb150);
            this.Controls.Add(this.vkkb149);
            this.Controls.Add(this.vkkb148);
            this.Controls.Add(this.vkkb147);
            this.Controls.Add(this.vkkb146);
            this.Controls.Add(this.vkkb145);
            this.Controls.Add(this.vkkb144);
            this.Controls.Add(this.vkkb143);
            this.Controls.Add(this.vkkb142);
            this.Controls.Add(this.vkkb141);
            this.Controls.Add(this.vkkb140);
            this.Controls.Add(this.vkkb139);
            this.Controls.Add(this.vkkb138);
            this.Controls.Add(this.vkkb137);
            this.Controls.Add(this.vkkb136);
            this.Controls.Add(this.vkkb135);
            this.Controls.Add(this.vkkb134);
            this.Controls.Add(this.vkkb133);
            this.Controls.Add(this.vkkb132);
            this.Controls.Add(this.vkkb131);
            this.Controls.Add(this.vkkb130);
            this.Controls.Add(this.vkkb129);
            this.Controls.Add(this.vkkb128);
            this.Controls.Add(this.vkkb127);
            this.Controls.Add(this.vkkb126);
            this.Controls.Add(this.vkkb125);
            this.Controls.Add(this.vkkb124);
            this.Controls.Add(this.vkkb123);
            this.Controls.Add(this.vkkb122);
            this.Controls.Add(this.vkkb121);
            this.Controls.Add(this.vkkb120);
            this.Controls.Add(this.vkkb119);
            this.Controls.Add(this.vkkb118);
            this.Controls.Add(this.vkkb117);
            this.Controls.Add(this.vkkb116);
            this.Controls.Add(this.vkkb115);
            this.Controls.Add(this.vkkb114);
            this.Controls.Add(this.vkkb113);
            this.Controls.Add(this.vkkb112);
            this.Controls.Add(this.vkkb111);
            this.Controls.Add(this.vkkb110);
            this.Controls.Add(this.vkkb109);
            this.Controls.Add(this.vkkb108);
            this.Controls.Add(this.vkkb107);
            this.Controls.Add(this.vkkb106);
            this.Controls.Add(this.vkkb105);
            this.Controls.Add(this.vkkb104);
            this.Controls.Add(this.vkkb103);
            this.Controls.Add(this.vkkb102);
            this.Controls.Add(this.vkkb101);
            this.Controls.Add(this.vkkb100);
            this.Controls.Add(this.vkkb99);
            this.Controls.Add(this.vkkb98);
            this.Controls.Add(this.vkkb97);
            this.Controls.Add(this.vkkb96);
            this.Controls.Add(this.vkkb95);
            this.Controls.Add(this.vkkb94);
            this.Controls.Add(this.vkkb93);
            this.Controls.Add(this.vkkb92);
            this.Controls.Add(this.vkkb91);
            this.Controls.Add(this.vkkb90);
            this.Controls.Add(this.vkkb89);
            this.Controls.Add(this.vkkb88);
            this.Controls.Add(this.vkkb87);
            this.Controls.Add(this.vkkb86);
            this.Controls.Add(this.vkkb85);
            this.Controls.Add(this.vkkb84);
            this.Controls.Add(this.vkkb83);
            this.Controls.Add(this.vkkb82);
            this.Controls.Add(this.vkkb81);
            this.Controls.Add(this.vkkb80);
            this.Controls.Add(this.vkkb79);
            this.Controls.Add(this.vkkb78);
            this.Controls.Add(this.vkkb77);
            this.Controls.Add(this.vkkb76);
            this.Controls.Add(this.vkkb75);
            this.Controls.Add(this.vkkb74);
            this.Controls.Add(this.vkkb73);
            this.Controls.Add(this.vkkb72);
            this.Controls.Add(this.vkkb71);
            this.Controls.Add(this.vkkb70);
            this.Controls.Add(this.vkkb69);
            this.Controls.Add(this.vkkb68);
            this.Controls.Add(this.vkkb67);
            this.Controls.Add(this.vkkb66);
            this.Controls.Add(this.vkkb65);
            this.Controls.Add(this.vkkb64);
            this.Controls.Add(this.vkkb63);
            this.Controls.Add(this.vkkb62);
            this.Controls.Add(this.vkkb61);
            this.Controls.Add(this.vkkb60);
            this.Controls.Add(this.vkkb59);
            this.Controls.Add(this.vkkb58);
            this.Controls.Add(this.vkkb57);
            this.Controls.Add(this.vkkb56);
            this.Controls.Add(this.vkkb55);
            this.Controls.Add(this.vkkb54);
            this.Controls.Add(this.vkkb53);
            this.Controls.Add(this.vkkb52);
            this.Controls.Add(this.vkkb51);
            this.Controls.Add(this.vkkb50);
            this.Controls.Add(this.vkkb49);
            this.Controls.Add(this.vkkb48);
            this.Controls.Add(this.vkkb47);
            this.Controls.Add(this.vkkb46);
            this.Controls.Add(this.vkkb45);
            this.Controls.Add(this.vkkb44);
            this.Controls.Add(this.vkkb43);
            this.Controls.Add(this.vkkb42);
            this.Controls.Add(this.vkkb41);
            this.Controls.Add(this.vkkb40);
            this.Controls.Add(this.vkkb39);
            this.Controls.Add(this.vkkb38);
            this.Controls.Add(this.vkkb37);
            this.Controls.Add(this.vkkb36);
            this.Controls.Add(this.vkkb35);
            this.Controls.Add(this.vkkb34);
            this.Controls.Add(this.vkkb33);
            this.Controls.Add(this.vkkb32);
            this.Controls.Add(this.vkkb31);
            this.Controls.Add(this.vkkb30);
            this.Controls.Add(this.vkkb29);
            this.Controls.Add(this.vkkb28);
            this.Controls.Add(this.vkkb27);
            this.Controls.Add(this.vkkb26);
            this.Controls.Add(this.vkkb25);
            this.Controls.Add(this.vkkb24);
            this.Controls.Add(this.vkkb23);
            this.Controls.Add(this.vkkb22);
            this.Controls.Add(this.vkkb21);
            this.Controls.Add(this.vkkb20);
            this.Controls.Add(this.vkkb19);
            this.Controls.Add(this.vkkb18);
            this.Controls.Add(this.vkkb17);
            this.Controls.Add(this.vkkb16);
            this.Controls.Add(this.vkkb15);
            this.Controls.Add(this.vkkb14);
            this.Controls.Add(this.vkkb13);
            this.Controls.Add(this.vkkb12);
            this.Controls.Add(this.vkkb11);
            this.Controls.Add(this.vkkb10);
            this.Controls.Add(this.vkkb9);
            this.Controls.Add(this.vkkb8);
            this.Controls.Add(this.vkkb7);
            this.Controls.Add(this.vkkb6);
            this.Controls.Add(this.vkkb5);
            this.Controls.Add(this.vkkb4);
            this.Controls.Add(this.vkkb3);
            this.Controls.Add(this.vkkb2);
            this.Controls.Add(this.vkkb1);
            this.Controls.Add(this.textBox1);
            this.Name = "Form1";
            this.Text = "virtual keyboard with controls and button";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private vkkb vkkb1;
        private vkkb vkkb2;
        private vkkb vkkb3;
        private vkkb vkkb4;
        private vkkb vkkb5;
        private vkkb vkkb6;
        private vkkb vkkb7;
        private vkkb vkkb8;
        private vkkb vkkb9;
        private vkkb vkkb10;
        private vkkb vkkb11;
        private vkkb vkkb12;
        private vkkb vkkb13;
        private vkkb vkkb14;
        private vkkb vkkb15;
        private vkkb vkkb16;
        private vkkb vkkb17;
        private vkkb vkkb18;
        private vkkb vkkb19;
        private vkkb vkkb20;
        private vkkb vkkb21;
        private vkkb vkkb22;
        private vkkb vkkb23;
        private vkkb vkkb24;
        private vkkb vkkb25;
        private vkkb vkkb26;
        private vkkb vkkb27;
        private vkkb vkkb28;
        private vkkb vkkb29;
        private vkkb vkkb30;
        private vkkb vkkb31;
        private vkkb vkkb32;
        private vkkb vkkb33;
        private vkkb vkkb34;
        private vkkb vkkb35;
        private vkkb vkkb36;
        private vkkb vkkb37;
        private vkkb vkkb38;
        private vkkb vkkb39;
        private vkkb vkkb40;
        private vkkb vkkb41;
        private vkkb vkkb42;
        private vkkb vkkb43;
        private vkkb vkkb44;
        private vkkb vkkb45;
        private vkkb vkkb46;
        private vkkb vkkb47;
        private vkkb vkkb48;
        private vkkb vkkb49;
        private vkkb vkkb50;
        private vkkb vkkb51;
        private vkkb vkkb52;
        private vkkb vkkb53;
        private vkkb vkkb54;
        private vkkb vkkb55;
        private vkkb vkkb56;
        private vkkb vkkb57;
        private vkkb vkkb58;
        private vkkb vkkb59;
        private vkkb vkkb60;
        private vkkb vkkb61;
        private vkkb vkkb62;
        private vkkb vkkb63;
        private vkkb vkkb64;
        private vkkb vkkb65;
        private vkkb vkkb66;
        private vkkb vkkb67;
        private vkkb vkkb68;
        private vkkb vkkb69;
        private vkkb vkkb70;
        private vkkb vkkb71;
        private vkkb vkkb72;
        private vkkb vkkb73;
        private vkkb vkkb74;
        private vkkb vkkb75;
        private vkkb vkkb76;
        private vkkb vkkb77;
        private vkkb vkkb78;
        private vkkb vkkb79;
        private vkkb vkkb80;
        private vkkb vkkb81;
        private vkkb vkkb82;
        private vkkb vkkb83;
        private vkkb vkkb84;
        private vkkb vkkb85;
        private vkkb vkkb86;
        private vkkb vkkb87;
        private vkkb vkkb88;
        private vkkb vkkb89;
        private vkkb vkkb90;
        private vkkb vkkb91;
        private vkkb vkkb92;
        private vkkb vkkb93;
        private vkkb vkkb94;
        private vkkb vkkb95;
        private vkkb vkkb96;
        private vkkb vkkb97;
        private vkkb vkkb98;
        private vkkb vkkb99;
        private vkkb vkkb100;
        private vkkb vkkb101;
        private vkkb vkkb102;
        private vkkb vkkb103;
        private vkkb vkkb104;
        private vkkb vkkb105;
        private vkkb vkkb106;
        private vkkb vkkb107;
        private vkkb vkkb108;
        private vkkb vkkb109;
        private vkkb vkkb110;
        private vkkb vkkb111;
        private vkkb vkkb112;
        private vkkb vkkb113;
        private vkkb vkkb114;
        private vkkb vkkb115;
        private vkkb vkkb116;
        private vkkb vkkb117;
        private vkkb vkkb118;
        private vkkb vkkb119;
        private vkkb vkkb120;
        private vkkb vkkb121;
        private vkkb vkkb122;
        private vkkb vkkb123;
        private vkkb vkkb124;
        private vkkb vkkb125;
        private vkkb vkkb126;
        private vkkb vkkb127;
        private vkkb vkkb128;
        private vkkb vkkb129;
        private vkkb vkkb130;
        private vkkb vkkb131;
        private vkkb vkkb132;
        private vkkb vkkb133;
        private vkkb vkkb134;
        private vkkb vkkb135;
        private vkkb vkkb136;
        private vkkb vkkb137;
        private vkkb vkkb138;
        private vkkb vkkb139;
        private vkkb vkkb140;
        private vkkb vkkb141;
        private vkkb vkkb142;
        private vkkb vkkb143;
        private vkkb vkkb144;
        private vkkb vkkb145;
        private vkkb vkkb146;
        private vkkb vkkb147;
        private vkkb vkkb148;
        private vkkb vkkb149;
        private vkkb vkkb150;
        private vkkb vkkb151;
        private vkkb vkkb152;
        private vkkb vkkb153;
        private vkkb vkkb154;
        private vkkb vkkb155;
        private vkkb vkkb156;
        private vkkb vkkb157;
        private vkkb vkkb158;
        private vkkb vkkb159;
        private vkkb vkkb160;
        private vkkb vkkb161;
        private vkkb vkkb162;
        private vkkb vkkb163;
        private vkkb vkkb164;
        private vkkb vkkb165;
        private vkkb vkkb166;
        private vkkb vkkb167;
        private vkkb vkkb168;
        private vkkb vkkb169;
        private vkkb vkkb170;
        private vkkb vkkb171;
        private vkkb vkkb172;
        private vkkb vkkb173;
        private vkkb vkkb174;
        private vkkb vkkb175;
        private vkkb vkkb176;
    }
}

